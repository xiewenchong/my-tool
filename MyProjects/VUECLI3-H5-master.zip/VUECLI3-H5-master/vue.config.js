module.exports = {
  devServer: {
    disableHostCheck: true,
  },
  // 基本路径
  publicPath: '/wx/',
  // // 打包构建的文件目录
  outputDir:'dist',
  // // 指定生成index.html的输出路径
  // indexPath:'index.html',
  // // 存放静态资源的目录
  // assetsDir:'asserts'
}