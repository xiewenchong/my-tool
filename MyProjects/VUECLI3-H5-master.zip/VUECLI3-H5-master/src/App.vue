<template>
  <div id="app">
    <router-view/>
  </div>
</template>

<style lang="scss">
ul{
  list-style: none;
  margin: 0;
  padding: 0;
}
</style>
<style>
@import './style/index.css';
</style>
