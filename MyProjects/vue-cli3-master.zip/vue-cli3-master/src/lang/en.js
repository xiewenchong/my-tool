export default {
    navbar: {
        Home: 'Home',
        About: 'About',
        Test: 'Test'
    },
    skin: {
      Black: 'Black Skin',
      Default: 'White Skin'
    },
    layer:{
      tips:'Tips',
      sure:'Determine test',
    },
    button:{
      ok:'OK',
      cancel:'Cancel'
    },
    message:{
      changeSkin:'Change Skin',
      testLang:'Test i18n'
    }
  }