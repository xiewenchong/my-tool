export default {
    navbar: {
        Home: '主页',
        About: '关于',
        Test: '测试'
    },
    skin: {
      Black: '酷黑风格',
      Default: '亮白风格'
    },
    layer:{
      tips:'提示',
      sure:'确定测试',
    },
    button:{
      ok:'确定',
      cancel:'取消'
    },
    message:{
      changeSkin:'切换风格',
      testLang:'测试国际化'
    }
  }