<template>
  <div class="component-a">
    这里是业务组件 A
  </div>
</template>

<script>
export default {
  name: "component-a"
};
</script>

<style lang="stylus" scoped>
.component-a
  color blue
</style>
