<template>
  <div class="business-c-page-a">
    <h1 class="title">页面B</h1>
    这里是业务 C 页面 B
  </div>
</template>

<script>
export default {
  name: "business-c-page-b"
};
</script>

<style lang="stylus" scoped>
.title
  color pink
</style>
