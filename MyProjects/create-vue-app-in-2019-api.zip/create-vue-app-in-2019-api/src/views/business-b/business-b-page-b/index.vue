<template>
  <div class="business-b-page-a">
    <h1 class="title">页面B</h1>
    这里是业务 B 页面 B
  </div>
</template>

<script>
export default {
  name: "business-b-page-b"
};
</script>

<style lang="stylus" scoped>
.title
  color pink
</style>
